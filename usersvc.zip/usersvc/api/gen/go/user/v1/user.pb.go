// Minimal hand-written structures mirroring api/proto/user/v1/user.proto.
// They only provide the functionality the service and tests rely on.

package userv1

type CreateUserRequest struct {
	Name  string `json:"name,omitempty"`
	Email string `json:"email,omitempty"`
}

func (x *CreateUserRequest) GetName() string {
	if x == nil {
		return ""
	}
	return x.Name
}

func (x *CreateUserRequest) GetEmail() string {
	if x == nil {
		return ""
	}
	return x.Email
}

type CreateUserResponse struct {
	UserId string `json:"user_id,omitempty"`
}

func (x *CreateUserResponse) GetUserId() string {
	if x == nil {
		return ""
	}
	return x.UserId
}
